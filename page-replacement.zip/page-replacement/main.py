from collections import deque, defaultdict
from typing import List, Dict, Any, Tuple
import random
import matplotlib.pyplot as plt


# -------------------------
# Algorithms
# -------------------------

def simulate_fifo(pages: List[int], frames_count: int) -> Dict[str, Any]:
    frames = []
    q = deque()
    faults = 0
    steps = []

    for p in pages:
        hit = p in frames
        if not hit:
            faults += 1
            if len(frames) < frames_count:
                frames.append(p)
                q.append(p)
            else:
                victim = q.popleft()
                victim_index = frames.index(victim)
                frames[victim_index] = p
                q.append(p)
        steps.append({"page": p, "frames": frames.copy(), "hit": hit, "faults": faults})

    return {"name": "FIFO", "faults": faults, "steps": steps}


def simulate_lru(pages: List[int], frames_count: int) -> Dict[str, Any]:
    frames = []
    last_used = {}  # page -> last index/time
    faults = 0
    steps = []

    for t, p in enumerate(pages):
        hit = p in frames
        if hit:
            last_used[p] = t
        else:
            faults += 1
            if len(frames) < frames_count:
                frames.append(p)
                last_used[p] = t
            else:
                victim = min(frames, key=lambda x: last_used.get(x, -1))
                victim_index = frames.index(victim)
                frames[victim_index] = p
                last_used.pop(victim, None)
                last_used[p] = t

        steps.append({"page": p, "frames": frames.copy(), "hit": hit, "faults": faults})

    return {"name": "LRU", "faults": faults, "steps": steps}


def simulate_optimal(pages: List[int], frames_count: int) -> Dict[str, Any]:
    frames = []
    faults = 0
    steps = []

    for i, p in enumerate(pages):
        hit = p in frames
        if not hit:
            faults += 1
            if len(frames) < frames_count:
                frames.append(p)
            else:
                next_use = {}
                for f in frames:
                    try:
                        nxt = pages.index(f, i + 1)
                    except ValueError:
                        nxt = float("inf")
                    next_use[f] = nxt

                victim = max(frames, key=lambda x: next_use[x])
                frames[frames.index(victim)] = p

        steps.append({"page": p, "frames": frames.copy(), "hit": hit, "faults": faults})

    return {"name": "OPT", "faults": faults, "steps": steps}


def simulate_lfu(pages: List[int], frames_count: int) -> Dict[str, Any]:
    frames = []
    freq = defaultdict(int)  # page -> frequency
    age = {}                 # page -> time inserted (for tie-break)
    faults = 0
    steps = []

    for t, p in enumerate(pages):
        hit = p in frames
        if hit:
            freq[p] += 1
        else:
            faults += 1
            if len(frames) < frames_count:
                frames.append(p)
                freq[p] += 1
                age[p] = t
            else:
                # LFU: min frequency, tie-break by oldest
                victim = min(frames, key=lambda x: (freq[x], age.get(x, -1)))
                frames[frames.index(victim)] = p

                freq.pop(victim, None)
                age.pop(victim, None)
                freq[p] += 1
                age[p] = t

        steps.append({"page": p, "frames": frames.copy(), "hit": hit, "faults": faults})

    return {"name": "LFU", "faults": faults, "steps": steps}


def simulate_second_chance(pages: List[int], frames_count: int) -> Dict[str, Any]:
    # Also known as Clock algorithm
    frames = [None] * frames_count
    ref_bit = [0] * frames_count
    pointer = 0
    faults = 0
    steps = []

    for p in pages:
        if p in frames:
            hit = True
            idx = frames.index(p)
            ref_bit[idx] = 1
        else:
            hit = False
            faults += 1

            while True:
                if frames[pointer] is None:
                    frames[pointer] = p
                    ref_bit[pointer] = 1
                    pointer = (pointer + 1) % frames_count
                    break

                if ref_bit[pointer] == 0:
                    frames[pointer] = p
                    ref_bit[pointer] = 1
                    pointer = (pointer + 1) % frames_count
                    break
                else:
                    ref_bit[pointer] = 0
                    pointer = (pointer + 1) % frames_count

        current_frames = [x for x in frames if x is not None]
        steps.append({"page": p, "frames": current_frames.copy(), "hit": hit, "faults": faults})

    return {"name": "SecondChance", "faults": faults, "steps": steps}


def simulate_random(pages: List[int], frames_count: int, seed: int = 42) -> Dict[str, Any]:
    rng = random.Random(seed)
    frames = []
    faults = 0
    steps = []

    for p in pages:
        hit = p in frames
        if not hit:
            faults += 1
            if len(frames) < frames_count:
                frames.append(p)
            else:
                victim_index = rng.randrange(frames_count)
                frames[victim_index] = p

        steps.append({"page": p, "frames": frames.copy(), "hit": hit, "faults": faults})

    return {"name": f"Random(seed={seed})", "faults": faults, "steps": steps}


# -------------------------
# Analyzer
# -------------------------

def run_analyzer_all(pages: List[int], frames_count: int, random_seed: int = 42) -> List[Dict[str, Any]]:
    if frames_count <= 0:
        raise ValueError("frames_count must be >= 1")
    if not pages:
        raise ValueError("pages list cannot be empty")

    results = [
        simulate_fifo(pages, frames_count),
        simulate_lru(pages, frames_count),
        simulate_optimal(pages, frames_count),
        simulate_lfu(pages, frames_count),
        simulate_second_chance(pages, frames_count),
        simulate_random(pages, frames_count, seed=random_seed),
    ]
    return results


def print_steps(result: Dict[str, Any]) -> None:
    print(f"\n=== {result['name']} Simulation ===")
    print("Step | Page | Hit?  | Frames                 | Faults")
    print("-----+------+-------+------------------------+-------")
    for idx, s in enumerate(result["steps"], start=1):
        hit_str = "HIT " if s["hit"] else "FAULT"
        frames_str = str(s["frames"])
        print(f"{idx:>4} | {s['page']:>4} | {hit_str:<5} | {frames_str:<22} | {s['faults']:>5}")
    print(f"Total Page Faults ({result['name']}): {result['faults']}")


def print_summary(results: List[Dict[str, Any]]) -> None:
    print("\n=== Final Comparison ===")
    for r in results:
        print(f"{r['name']}: {r['faults']} page faults")
    best = min(results, key=lambda x: x["faults"])
    print(f"\nBest (fewest faults): {best['name']}")


# -------------------------
# Graphs (Required)
# -------------------------

def plot_faults_bar(results: List[Dict[str, Any]]) -> None:
    names = [r["name"] for r in results]
    faults = [r["faults"] for r in results]

    plt.figure()
    plt.bar(names, faults)
    plt.title("Page Faults by Algorithm")
    plt.xlabel("Algorithm")
    plt.ylabel("Total Page Faults")
    plt.xticks(rotation=25, ha="right")
    plt.tight_layout()
    plt.show()


def plot_cumulative_faults(results: List[Dict[str, Any]]) -> None:
    plt.figure()
    for r in results:
        x = list(range(1, len(r["steps"]) + 1))
        y = [s["faults"] for s in r["steps"]]
        plt.plot(x, y, label=r["name"])
    plt.title("Cumulative Page Faults Over Time")
    plt.xlabel("Step")
    plt.ylabel("Cumulative Faults")
    plt.legend()
    plt.tight_layout()
    plt.show()


def plot_faults_vs_frames(pages: List[int], max_frames: int = 10, random_seed: int = 42) -> None:
    algos = [
        ("FIFO", lambda p, f: simulate_fifo(p, f)["faults"]),
        ("LRU", lambda p, f: simulate_lru(p, f)["faults"]),
        ("OPT", lambda p, f: simulate_optimal(p, f)["faults"]),
        ("LFU", lambda p, f: simulate_lfu(p, f)["faults"]),
        ("SecondChance", lambda p, f: simulate_second_chance(p, f)["faults"]),
        (f"Random(seed={random_seed})", lambda p, f: simulate_random(p, f, seed=random_seed)["faults"]),
    ]

    plt.figure()
    frames_range = list(range(1, max_frames + 1))

    for name, fn in algos:
        faults_list = [fn(pages, f) for f in frames_range]
        plt.plot(frames_range, faults_list, label=name)

    plt.title("Page Faults vs Number of Frames")
    plt.xlabel("Frames")
    plt.ylabel("Total Page Faults")
    plt.legend()
    plt.tight_layout()
    plt.show()


# -------------------------
# Main (User Input)
# -------------------------

pages_str = input("Enter page reference string (space-separated): ").strip()
frames_count = int(input("Enter number of frames: ").strip())
pages = [int(x) for x in pages_str.split()]

results = run_analyzer_all(pages, frames_count, random_seed=42)

# Print step-by-step simulations (you can turn this off for very long inputs)
for r in results:
    print_steps(r)

print_summary(results)

# Graphs
plot_faults_bar(results)
plot_cumulative_faults(results)

# Best graph for report: how faults change when frames increase
plot_faults_vs_frames(pages, max_frames=max(10, frames_count + 5), random_seed=42)
